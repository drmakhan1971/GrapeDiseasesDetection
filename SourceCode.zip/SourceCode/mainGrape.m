% % Detection and Classification of Grape Diseases
clc, close all, clear all

datasetRootFolder = 'C:\Work\GrapeImagesDataSet\';

% colorSpace = 'rgb';
% colorSpace = 'ycbcr';
% colorSpace = 'hsv';
colorSpace = 'lab';


seedRandom = rng('shuffle'); % % random every time run the program

K = 500;                     % % Value of K for K-mean clustering (500 is suitable)

% % Specify the training part of data, P in the range: 0-1
% % Example. P = 0.3 then 30% for training & 70% for validation
P = 0.2;
P_Percentage = P*100;         % % percentage of training data
Q_Percentage = (1 - P)*100;   % % percentage of testing data
% % ----------------------------------------------------

imgSets = getAllImgSetsFromRootDir(datasetRootFolder);
setCount = length(imgSets); % % number of sets
for k = 1:setCount
    fprintf('Image set %g:  %s,  Image count: %g \n',k,...
        imgSets(k).Description, imgSets(k).Count);
end
% Use partition method to trim the set.
minSetCount = min([imgSets.Count]); % % take smallest no. of images in a category
imgSets = partition(imgSets, minSetCount, 'randomize');
% % ----------------------------------------------------
% % Randomly partition the sets into training and validation data
[trainingSets, testingSets] = partition(imgSets, P, 'randomize');

% % For given training set of images do following
% % (1) Extract features
% % (2) K-means clustering
% % (3) Train SVM classifer
tic
if (isequal(colorSpace,'rgb')||isequal(colorSpace,'ycbcr')||...
        isequal(colorSpace,'hsv')||isequal(colorSpace,'lab'))
    extractorFcn = @(img)customColorspaceBagOfFeatures(img, colorSpace);
    bag = bagOfFeatures(trainingSets,'CustomExtractor', extractorFcn,...
        'VocabularySize', K);
elseif isequal(colorSpace,'graysurf')
    bag = bagOfFeatures(trainingSets,'VocabularySize',K,...
        'PointSelection','Grid','GridStep',[32 32]);
else
    error('This color-space is not supported');
end
categoryClassifier = trainImageCategoryClassifier(trainingSets, bag);
timeTraining = toc;
% % ----------------------------------------------------
% % get confusion matrix of test set
tic
cfmat = evaluate(categoryClassifier, testingSets);
timeTesting = toc;


cfmatDiag=diag(cfmat)';           % % accuracy of each class
accuracyMean = mean(diag(cfmat)); % % mean accuracy


N = [ones(1,4)*minSetCount];      % % (training+testing] images in each class

N2EachClass = N*P_Percentage/100; % % testing images in each class

% % ClassLabels = ["1-BlackMeasles", "2-BlackRot", "3-LeafBlight", "4-HealthyLeaves"];
ClassLabels = ["1", "2", "3","4"];

[cmChart,confusionMatrix] = confchartfromaccuracy(cfmat, N2EachClass, ClassLabels);
confusionMatrix

fprintf('% ----------------------------------------------------');
fprintf('Color-space: %s \n',colorSpace);
fprintf('Training   images: %g %% \n',P_Percentage);
fprintf('Testing images: %g %% \n',Q_Percentage);
fprintf('Minimum images taken from each set %g: \n',minSetCount);
fprintf('Training images count: %g \n',trainingSets(1).Count);
fprintf('Testing images count: %g \n',testingSets(1).Count);
fprintf('Vocabulary size for k-mean clustering: %g \n',K);
fprintf('Mean Training Time: %g seconds \n',timeTraining);
fprintf('Mean Testing time: %g seconds \n',timeTesting);
fprintf('Accuracy of class Black-measles : %g %%  \n',cfmatDiag(1)*100);
fprintf('Accuracy of class Black-rot     : %g %%  \n',cfmatDiag(2)*100);
fprintf('Accuracy of class Healthy-leaves: %g %%  \n',cfmatDiag(3)*100);
fprintf('Accuracy of class Leaf-blight   : %g %%  \n',cfmatDiag(4)*100);
fprintf('Mean Accuracy                   : %g %%  \n',accuracyMean*100);


