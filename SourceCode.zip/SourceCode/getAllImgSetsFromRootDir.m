% % Get image sets of all the directories (folders) inside the
% % spcified root directory

% % INPUT 
% % rootFolder: root directory (folder)

% % OUTPUT
% % imgSets: image sets inside root directory 
% % 

% % Example: 
% % rootFolder = 'M:\AI\AI_Img\TestImages\Grape_plantvillage\Test'
% % suppose there are four directories (folders) inside rootFolder
% % 1) BlackMeaslesGrapes
% % 2) BlackRotGrapes
% % 3) HealthyGrapes
% % 4) LeafBlightGrapes
% % Then imgSets will be
% % imgSets = [
% %     imageSet(fullfile(rootFolder, 'BlackMeaslesGrapes')), ...
% %     imageSet(fullfile(rootFolder, 'BlackRotGrapes')), ...    
% %     imageSet(fullfile(rootFolder, 'HealthyGrapes')), ...
% %     imageSet(fullfile(rootFolder, 'LeafBlightGrapes'))
% %     ];


function imgSets = getAllImgSetsFromRootDir(rootFolder)


[subFolders1, subFolders2]=subfoldersInFolders(rootFolder);


for k = 1 : length(subFolders2)
    imgSet = imageSet(fullfile(rootFolder, subFolders2(k).name));
     imgSets(k) = imgSet;
end



