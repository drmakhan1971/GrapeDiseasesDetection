% % Plot confusion chart from 2D normalized confusion matrix

% % INPUT
% % cm: confusion matrix as 2D array of normalized accuracies (b/w 0 & 1) 
% % N : 1D vector of number of images in each class 

% % OUTPUT
% % cmChart: ConfusionMatrixChart  as return by MATLAB builtin function
% % cm: confusion matrix with actucal number of predicated values
function [cmChart,cm] = confchartfromaccuracy(cm, N, ClassLabels, w, h)

argCountIn = nargin; % % number of input arguments

[r, c] = size(cm);

for k = 1:c
    cm(:,k) = cm(:,k)*N(k);
end

cm = round(cm);

if argCountIn == 2
    w = 256;
    h = w;
    cmChart = confusionchart(cm);
elseif argCountIn == 3
    w = 256;
    h = w;
    cmChart = confusionchart(cm, ClassLabels);
elseif argCountIn == 4 
    h = w;
    cmChart = confusionchart(cm, ClassLabels);
elseif argCountIn == 5
    cmChart = confusionchart(cm, ClassLabels);
end

% % position of screen where to show the figure
x = 100;
y = x;

title(""); set(gcf,'Position',[x y x+w y+h]);

