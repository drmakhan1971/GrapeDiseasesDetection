% % get list of subfolders in the specified folder (path)
% % search only 1 level (no nested search)

% % INPUT
% % myPath: specified folder (top level dir)

% % OUTPUT
% % subFolders1: list of all subfolders in myPath
% % subFolders2: list of subfolders except '.' and '..' in myPath

% % subFolders1 and subFolders2 are structures with following fields
% % name
% % date
% % bytes
% % isdir
% % datenum
    
% % e.g., subFolders1(k).name is name of kth subfolder

function [subFolders1, subFolders2]=subfoldersInFolders(myPath)


% % Get a list of all files and folders in this folder.
files = dir(myPath);

% % Get a logical vector that tells which is a directory.
dirFlags = [files.isdir];

% % Extract only those that are directories.
subFolders1 = files(dirFlags);


% % Create subfolder2 from subfolder1  by removing '.' & '..'  entries
c = 0;
for k = 1 : length(subFolders1)
    if ( ~isequal(subFolders1(k).name, '.') && ~isequal(subFolders1(k).name, '..') )
        c = c + 1;  
        for fn = fieldnames(subFolders1)'
            subFolders2(c).(fn{1}) = subFolders1(k).(fn{1});
        end        
    end
end

subFolders2 = subFolders2';


