function DisplayRequiredFunctions(fullFileName)
try
	if ~isdeployed
		[~, baseFileNameNoExt, ext] = fileparts(fullFileName);
		baseFileName = [baseFileNameNoExt, '.m'];
		[requiredFileList, toolboxList] = matlab.codetools.requiredFilesAndProducts(fullFileName);
		fprintf('Required m-files for %s:\n', baseFileName);
		for k = 1 : length(requiredFileList)
			fprintf('    %s\n', requiredFileList{k});
		end
		fprintf('Required MATLAB Toolboxes for %s:\n', baseFileName);
		for k = 1 : length(toolboxList)
			fprintf('    %s\n', toolboxList(k).Name);
		end
	end
catch ME
end